import cv2
import numpy as np
import matplotlib.pyplot as plt


def image_filter_choice():
    """Choose an example image and filter style to use in this program."""

    image_option = 0
    filter_option = ""

    if image_option != int(1) or image_option != int(2):
        image_option = int(input("Choose an Example Image (1 or 2): "))
    IMAGE_FILE_NAME = "sample" + str(image_option) + ".jpg"

    if filter_option != "blur" or filter_option != "sharpen" or filter_option != "outline":
        filter_option = input("Choose a Kernel (Blur, Sharpen, or Outline): ").lower()
    FILTER_KERNEL = filter_option

    return IMAGE_FILE_NAME, FILTER_KERNEL


def open_image(image_file_name):
    """Open the user selected image."""

    original_raw_image = cv2.imread(image_file_name)
    original_raw_image = cv2.cvtColor(original_raw_image, cv2.COLOR_BGR2RGB)

    return original_raw_image


def kernel_generator(filter_type):
    """Generates a blur and sharpen kernel based on user inputs to modify the original image."""

    print("\nInput 1 To Use The Standard Filter Kernel.")

    if filter_type == "blur":
        kernel_factor = float(input("Choose an Image Blur Factor. Factors Above 1 Increase Blur: "))
        raw_image_kernel = np.array([[0.0625, 0.125, 0.0625],
                                    [0.125, 0.25, 0.125],
                                    [0.0625, 0.125, 0.0625]], dtype=float)

    elif filter_type == "sharpen":
        kernel_factor = float(input("Choose an Image Sharpen Factor. Note: Factors Above 1 Increase Sharpening: "))
        raw_image_kernel = np.array([[0, -1, 0],
                                     [-1, 5, -1],
                                     [0, -1, 0]], dtype=float)

    else:
        kernel_factor = float(input("Choose an Image Outline Factor. Note: Factors Above 1 Increase Outlining: "))
        raw_image_kernel = np.array([[-1, -1, -1],
                                     [-1, 8, -1],
                                     [-1, -1, -1]], dtype=float)

    raw_image_kernel *= kernel_factor

    return raw_image_kernel

def filter_image(original_image, raw_image_kernel):
    filtered_image = cv2.filter2D(original_image, -1, raw_image_kernel)

    return filtered_image

def display_images(original_image, modified_image):
    fig, axis = plt.subplots(1, 2)

    axis[0].imshow(original_image)
    axis[0].axis('off')
    axis[0].set_title("Original Image")

    axis[1].imshow(modified_image)
    axis[1].axis('off')
    axis[1].set_title("Filtered Image")

    fig.tight_layout()
    plt.show()


def main():
    image_file, image_kernel_type = image_filter_choice()
    raw_image = open_image(image_file)
    image_kernel = kernel_generator(image_kernel_type)
    filtered_image = filter_image(raw_image, image_kernel)
    display_images(raw_image, filtered_image)


if __name__ == "__main__":
    main()
