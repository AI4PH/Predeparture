import os
import cv2
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Dense, Conv2D, MaxPool2D, Flatten, Dropout
from tensorflow.keras.models import Sequential
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report

# Get script and dataset file paths.
SCRIPT_PATH = os.path.dirname(__file__)
DATA_PATH = os.path.join(SCRIPT_PATH, "Brain_Tumor_Dataset")
# Variables corresponding to the minimum image size from the dataset
MIN_X = ""
MIN_Y = ""


def minimum_size():
    """Retrieves all images from the dataset folder and determines the smallest dimensions."""

    global MIN_X, MIN_Y

    min_image_x = ""
    min_image_y = ""

    # Loop through the entire dataset and recursively into the subdirectories to pull the image file names.
    for directory_path, directories, files in os.walk(DATA_PATH):
        for image in files:

            # Macs utilize a hidden file at the beginning of each folder, which for our purposes is useless.
            if image != ".DS_Store":
                # Read the image data
                image_file = cv2.imread(os.path.join(directory_path, image))

                # .shape returns the read images width, height, and colour channels.
                image_x, image_y, _ = image_file.shape

                # Assign the local function minimums to the width and height of the first image.
                if min_image_x == "" or min_image_y == "":
                    min_image_x, min_image_y = image_x, image_y

                if image_x < min_image_x:
                    min_image_x = image_x
                if image_y < min_image_y:
                    min_image_y = image_y

    # Set global minimum variable values to the local function determined minimums.
    MIN_X = min_image_x
    MIN_Y = min_image_y


def retrieve_data():
    """Retrieve and reshape the data from the dataset."""

    # Categorical labels corresponding to the absence (No) and presence of a tumor (Yes).
    labels = ["No", "Yes"]
    image_label_data = []

    # Loop through the individual dataset folders to read + reshape the images, and then append the data to the
    # image_label_data variable.
    for label in labels:
        data_label_path = os.path.join(DATA_PATH, label)
        for image in os.listdir(data_label_path):
            # Macs utilize a hidden file at the beginning of each folder, which for our purposes is useless.
            if image != ".DS_Store":
                # Read image data
                image_original = cv2.imread(os.path.join(data_label_path, image))
                # Reshape image to the minimum sizes defined globally
                image_resized = cv2.resize(image_original, (MIN_X, MIN_Y))
                # Append data to the image_label_data variable.
                image_label_data.append([image_resized, labels.index(label)])

    return np.array(image_label_data, dtype=object)


def preprocessing(image_data):
    """Separates the dataset image and label. Normalizes the image data to float32 ( / 255). Modifies the entire data
    set as the number of images to train from is very few. """
    training_sample = []
    training_label = []

    # Split the dataset image and label into the training_sample and training_label variables.
    for image, label in image_data:
        training_sample.append(image)
        training_label.append(label)

    # Normalize the image data and store as a numpy array.
    training_sample = np.array(training_sample) / 255
    training_label = np.array(training_label)

    # Reshape the training_sample data into an array matching the original.
    training_sample.reshape(-1, MIN_X, MIN_Y, 1)

    # Construct a data generator to create batches of tensor image data with data augmentation (rotation, zoom,
    # dimension shift, vertical/horizontal flips).
    data_gen = ImageDataGenerator(
        rotation_range=120,  # Randomly rotate images in the range (degrees, 0 to 180)
        zoom_range=0.3,  # Randomly zoom image
        width_shift_range=0.2,  # Randomly shift images horizontally (fraction of total width)
        height_shift_range=0.2,  # Randomly shift images vertically (fraction of total height)
        horizontal_flip=True,  # Randomly horizontally flip images
        vertical_flip=True)  # Randomly vertically flip images

    data_gen.fit(training_sample)

    return training_sample, training_label


def network(training_sample, training_label):
    """Construct an artificial neural network to feed the data through. The network flow through proceeds as follows:

            1.CONV2D --> 1.Pooling --> 2.CONV2D --> 2.Pooling --> 3.CONV2D --> 3.Pooling --> 1.Dropout --> 1.Flatten -->
            1.Dense --> 2.Dense

        Total Params == 3,125,602
        Trainable Params == 3,125,602 (Neuron weights that are updated with back-propagation)
        Non-trainable Parmas == 0 (Neuron weights that are NOT updated with back-propagation)
    """

    # Selected model is sequential
    model = Sequential()
    model.add(Conv2D(32, 3, padding="same", activation="relu", input_shape=(MIN_Y, MIN_X, 3)))
    model.add(MaxPool2D())

    model.add(Conv2D(32, 3, padding="same", activation="relu"))
    model.add(MaxPool2D())

    model.add(Conv2D(64, 3, padding="same", activation="relu"))
    model.add(MaxPool2D())
    model.add(Dropout(0.4))

    model.add(Flatten())
    model.add(Dense(128, activation="relu"))
    model.add(Dense(2, activation="softmax"))

    model.summary()

    # Note: Chose a low learning rate here to increase the number of epochs and ensure that the data extraction was
    # accurate <- Not totally sure if this is how it works though
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.00001),
                  loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                  metrics=['accuracy'])

    history = model.fit(training_sample, training_label, epochs=100, validation_split=0.3)

    predictions = model.predict_classes(training_sample)
    predictions = predictions.reshape(1, -1)[0]
    print(classification_report(training_label, predictions, target_names=['No Tumor (Class 0)', 'Tumor (Class 1)']))

    return history


def evaluate_accuracy(history):
    """Showcases both the accuracy and loss for both the training and testing data sets via a matplotlib plot."""

    training_accuracy = history.history['accuracy']
    testing_acc = history.history['val_accuracy']
    training_loss = history.history['loss']
    testing_loss = history.history['val_loss']

    epochs_range = range(100)

    # Plot the training and testing accuracy.
    plt.figure(figsize=(15, 15))
    plt.subplot(2, 2, 1)
    plt.plot(epochs_range, training_accuracy, label='Training Accuracy')
    plt.plot(epochs_range, testing_acc, label='Testing Accuracy')
    plt.legend(loc='lower right')
    plt.title('Training and Testing Accuracy')

    # Plot the training and testing loss.
    plt.subplot(2, 2, 2)
    plt.plot(epochs_range, training_loss, label='Training Loss')
    plt.plot(epochs_range, testing_loss, label='Testing Loss')
    plt.legend(loc='upper right')
    plt.title('Training and Testing Loss')
    plt.show()


def main():
    minimum_size()
    data = retrieve_data()
    training_sample_data, training_label_data = preprocessing(data)
    history = network(training_sample_data, training_label_data)
    evaluate_accuracy(history)


if __name__ == "__main__":
    main()

""" 
Code for the retrieve_data, preprocessing, network, and accuracy functions are heavily modified and altered forms 
of code obtained from: 
    https://www.analyticsvidhya.com/blog/2020/10/create-image-classification-model-python-keras/
    https://towardsdatascience.com/image-recognition-with-machine-learning-on-python-convolutional-neural-network-363073020588
    https://www.datacamp.com/community/tutorials/convolutional-neural-networks-python
    https://www.tensorflow.org/tutorials/images/classification
    https://www.tensorflow.org/tutorials/images/cnn
    https://stackabuse.com/image-recognition-in-python-with-tensorflow-and-keras
    https://www.tensorflow.org/tutorials/keras/classification
    https://medium.com/neuronio/how-to-deal-with-image-resizing-in-deep-learning-e5177fad7d89
    
The data set was retrieved from:
    https://www.kaggle.com/navoneel/brain-mri-images-for-brain-tumor-detection
"""